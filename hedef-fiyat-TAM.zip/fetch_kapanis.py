import json, yfinance as yf, os
HEDEFLER_FILE = "data/hedefler.json"
KAPANIS_FILE = "data/kapanis.json"
hedefler = json.load(open(HEDEFLER_FILE, encoding="utf-8"))
kodlar = sorted(set(h["kod"].upper() for h in hedefler))
kapanislar = json.load(open(KAPANIS_FILE, encoding="utf-8")) if os.path.exists(KAPANIS_FILE) else {}
for kod in kodlar:
    try:
        df = yf.download(kod + ".IS", period="90d", progress=False, auto_adjust=False)
        if df.empty: continue
        if kod not in kapanislar: kapanislar[kod] = {}
        for idx, row in df.iterrows():
            kapanislar[kod][idx.strftime("%Y-%m-%d")] = round(float(row["Close"]), 2)
    except Exception as e:
        print(kod, e)
json.dump(kapanislar, open(KAPANIS_FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
