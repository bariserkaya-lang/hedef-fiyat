from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json, os

app = FastAPI(title="Hedef Fiyat - Stabil")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DATA_DIR = "data"
HEDEFLER_FILE = os.path.join(DATA_DIR, "hedefler.json")
KAPANIS_FILE = os.path.join(DATA_DIR, "kapanis.json")
os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(HEDEFLER_FILE): json.dump([], open(HEDEFLER_FILE, "w", encoding="utf-8"))
if not os.path.exists(KAPANIS_FILE): json.dump({}, open(KAPANIS_FILE, "w", encoding="utf-8"))

class Hedef(BaseModel):
    kod: str
    kurum: str
    hedef: float
    tarih: str

@app.get("/")
def home():
    return FileResponse("index.html")

@app.get("/hedefler")
def get_hedefler():
    hedefler = json.load(open(HEDEFLER_FILE, encoding="utf-8"))
    kapanislar = json.load(open(KAPANIS_FILE, encoding="utf-8"))
    out = []
    for h in sorted(hedefler, key=lambda x: x["tarih"], reverse=True):
        kod = h["kod"].upper()
        kapanis = None
        if kod in kapanislar and kapanislar[kod]:
            kapanis = kapanislar[kod][sorted(kapanislar[kod].keys())[-1]]
        pot = round((h["hedef"]/kapanis - 1)*100, 1) if kapanis else None
        out.append({**h, "kapanis": kapanis, "pot": pot})
    return out

@app.post("/hedef-ekle")
def ekle(h: Hedef):
    hedefler = json.load(open(HEDEFLER_FILE, encoding="utf-8"))
    hedefler.append({"kod": h.kod.upper(), "kurum": h.kurum, "hedef": h.hedef, "tarih": h.tarih})
    json.dump(hedefler, open(HEDEFLER_FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return {"ok": True}

@app.get("/kapanis/{kod}")
def kapanis(kod: str):
    kapanislar = json.load(open(KAPANIS_FILE, encoding="utf-8"))
    data = kapanislar.get(kod.upper(), {})
    return [{"tarih": t, "kapanis": v} for t, v in sorted(data.items())]
